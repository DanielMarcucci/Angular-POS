import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { users } from "../interfaces/users";

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  constructor(private http: HttpClient) { }

  getToken(request: users) {
    this.http.get("http://localhost:8000/users").subscribe(data => {
      console.log(data);
    })
    //return this.http.post("http://localhost:8000/users/login", request);
  }
}
