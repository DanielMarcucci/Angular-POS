import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-panel',
  templateUrl: './c-panel.component.html',
  styleUrls: ['./c-panel.component.css']
})
export class CPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
