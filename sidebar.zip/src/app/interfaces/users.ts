export interface users {
  username: String,
  password: String
}