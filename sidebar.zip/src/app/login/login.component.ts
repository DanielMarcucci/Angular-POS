import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { UsersService } from "../services/users.service";
import { users } from "../interfaces/users";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  users: any = [];

  constructor(
    private router: Router,
    private usersServices: UsersService,
  ) { }

  ngOnInit() {
  }

  setUser(): users {
    return {
      username: "sr.prueba",
      password: "asdf"
    };
  }

  login() {
    this.usersServices.getToken(this.setUser())
    /*this.usersServices.getToken(this.setUser()).subscribe(data => {
      console.log(data);
    })*/
    //this.router.navigate(['pos']);
  }
  
}
